/**
 * Re-export useProject from ProjectContext
 * This file is kept for backward compatibility
 */
export { useProject } from '../context/ProjectContext';

export default useProject;
